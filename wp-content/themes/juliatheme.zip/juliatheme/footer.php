<!--footer-->
<div class="row">
	<footer class="site-footer col-md-10">
		<div class="sign">&copy;JULIA KAPTELOVA PHOTOGRAPHY, 2015, ALL RIGHT RESERVED</div>
		<ul class="right-bar-social-links">
			<li><a href="//instagram.com" class="instagram-normal" target="_blank"></a></li>
			<li><a href="//facebook.com" class="facebook-normal" target="_blank"></a></li>
			<li><a href="//vk.com" class="vk-normal" target="_blank"></a></li>
		</ul>
	</footer>
</div>
</div>

<?php wp_footer(); ?>
<script>
	//<![CDATA[
	var bs_pinButtonURL = "http://3.bp.blogspot.com/-y3xzTGiGzH0/UK4XOaUpdaI/AAAAAAAADw8/Z1MH4Jr4Efo/s1600/pinterestx1_72.png";
	var bs_pinButtonPos = "center";
	var bs_pinPrefix = "";
	var bs_pinSuffix = "";
	//]]>
</script>
<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js' type='text/javascript'></script>
<script id='bs_pinOnHover' src='http://greenlava-code.googlecode.com/svn/trunk/publicscripts/bs_pinOnHoverv1_min.js' type='text/javascript'>
	// This Pinterest Hover Button is brought to you by bloggersentral.com.
	// Visit http://www.bloggersentral.com/2012/11/pinterest-pin-it-button-on-image-hover.html for details.
	// Feel free to use and share, but please keep this notice intact.
</script>
</body>
</html>